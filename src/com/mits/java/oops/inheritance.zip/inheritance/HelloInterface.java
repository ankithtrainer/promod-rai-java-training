package com.mits.java.oops.inheritance;

public interface HelloInterface{


    public abstract void display();   // Abstract Method           // This task done by architect
    public abstract  void show();  // Method declaration


}
