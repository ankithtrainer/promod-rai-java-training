package com.mits.java.oops.inheritance.overriding;

public class SuperClass {

    public void showMe(){

        System.out.println( "  This is a Super Class .... ");

    }
}
