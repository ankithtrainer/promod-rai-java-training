package com.mits.java.oops.inheritance.overriding;

public class MainClass {

    public static void main(String[] args) {

        SubClass subClass = new SubClass();

        subClass.showMe();

    }
}
