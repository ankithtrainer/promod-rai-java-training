package com.mits.java.oops.inheritance.overriding;

public class SubClass extends SuperClass {


    public void showMe(){              //  Method Over riding

        System.out.println( "  This is a Sub Class .... ");

    }
}
