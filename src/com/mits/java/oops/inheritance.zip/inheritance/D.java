package com.mits.java.oops.inheritance;

public class D extends A{
}
