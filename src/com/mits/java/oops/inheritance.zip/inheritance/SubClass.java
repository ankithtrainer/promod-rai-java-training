package com.mits.java.oops.inheritance;

public class SubClass extends BaseClass{
    SubClass(String message){
        super(message);   // Super keyword  // It send message to base class constructor
    }

    SubClass(String message1, String message2){
        super(message1, message2);   // Super keyword  // It send message to base class constructor
    }

}
