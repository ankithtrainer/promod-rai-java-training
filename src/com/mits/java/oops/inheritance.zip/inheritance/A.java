package com.mits.java.oops.inheritance;

public class A {   // Base class or Super Class

    public void display(){    // Method definition
        System.out.println( "  This is  Base Class Method");

    }


}
