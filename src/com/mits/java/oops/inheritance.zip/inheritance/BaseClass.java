package com.mits.java.oops.inheritance;

public class BaseClass {

    BaseClass(String message){
        System.out.println( " This is Base/Super Class Constructor :  => " + message);
    }

    BaseClass(String message1, String message2){
        System.out.println( " This is Base/Super Class Constructor :  => " + message1);
        System.out.println( " This is Base/Super Class Constructor :  => " + message2);
    }
}
