package com.mits.java.oops.inheritance;

public class MainClass {

    public static void main(String[] args) {

          SubClass  subclassObject = new SubClass("Welcome");

        SubClass  subclassObject1 = new SubClass("Alok" , " Promod");

    }
}
