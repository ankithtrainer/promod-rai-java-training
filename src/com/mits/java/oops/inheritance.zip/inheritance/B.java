package com.mits.java.oops.inheritance;

public class B extends A{  // Subclass


}
