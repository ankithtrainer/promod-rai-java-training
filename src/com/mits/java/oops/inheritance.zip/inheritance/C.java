package com.mits.java.oops.inheritance;

public class C extends A{

   // Java does not support multiple inheritance  during class extension

}
